﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace bookshop
{
    public partial class books : Form
    {
        SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=bookshopp;Integrated Security=True");

        public books()
        {
            InitializeComponent();
            populate();
        }


        


        private void populate()
        {
            con.Open();
            string query = "SELECT * FROM BooksTbl";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            bookDGV.DataSource = ds.Tables[0];
            con.Close();
        }
        private void fillter()
        {
            if (catcbsearch.SelectedItem == null)
            {
                return;
            }

            con.Open();
            string query = "SELECT * FROM BooksTbl WHERE BCatogory = @Category";
            using (SqlCommand cmd = new SqlCommand(query, con))
            {
                cmd.Parameters.AddWithValue("@Category", catcbsearch.SelectedItem.ToString());
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                SqlCommandBuilder builder = new SqlCommandBuilder(sda);
                var ds = new DataSet();
                sda.Fill(ds);
                bookDGV.DataSource = ds.Tables[0];
            }
            con.Close();
        }
        private void savebtn_Click(object sender, EventArgs e)
        {
            if (Btitletb.Text == "" || Bautb.Text == "" || qtytb.Text == "" || bptb.Text == "" || bcatcb.SelectedIndex == -1)
            {
                MessageBox.Show("Missing information");
            }
            else
            {
                try
                {
                    con.Open();
                    string query = "INSERT INTO BooksTbl (BTitle, BAuthor, BCatogory, BQantity, BPrice) VALUES " +
                        "(@BTitle, @BAuthor, @BCatogory, @BQantity, @BPrice)";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@BTitle", Btitletb.Text);
                    cmd.Parameters.AddWithValue("@BAuthor", Bautb.Text);
                    cmd.Parameters.AddWithValue("@BCatogory", bcatcb.SelectedItem.ToString());
                    cmd.Parameters.AddWithValue("@BQantity", int.Parse(qtytb.Text));
                    cmd.Parameters.AddWithValue("@BPrice", double.Parse(bptb.Text));
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Book saved successfully");
                 
                    con.Close();
                    populate();
                    Reset();
                 
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void catcbsearch_SelectedIndexChanged(object sender, EventArgs e)
        {
            fillter();
        }

        private void refreshbtn_Click(object sender, EventArgs e)
        {
            populate();
            catcbsearch.SelectedIndex = -1;
        }
        public void Reset()
        {

            Btitletb.Text = "";
            Bautb.Text = "";
            bcatcb.SelectedIndex = -1;
            qtytb.Text = "";
            bptb.Text = "";
        }
        private void resetbtn_Click(object sender, EventArgs e)
        {
            Reset();
        }
        int key = 0;
        private void bookDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            Btitletb.Text = bookDGV.SelectedRows[0].Cells[1].Value.ToString();
            Bautb.Text = bookDGV.SelectedRows[0].Cells[2].Value.ToString();
            bcatcb.SelectedItem = bookDGV.SelectedRows[0].Cells[3].Value.ToString();
            qtytb.Text = bookDGV.SelectedRows[0].Cells[4].Value.ToString();
            bptb.Text = bookDGV.SelectedRows[0].Cells[5].Value.ToString();
            if(Btitletb.Text=="")
            {
                key = 0;
            }
            else
            {
                key = Convert.ToInt32(bookDGV.SelectedRows[0].Cells[0].Value.ToString());
            }

        }

        private void deletebtn_Click(object sender, EventArgs e)
        {
            if (Btitletb.Text == "" || Bautb.Text == "" || qtytb.Text == "" || bptb.Text == "" || bcatcb.SelectedIndex == -1)
            {
                MessageBox.Show("missing information");
            }
            else
            {

                try
                {
                    int key = Convert.ToInt32(bookDGV.SelectedRows[0].Cells[0].Value);

                    using (SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=bookshopp;Integrated Security=True"))
                    {
                        con.Open();
                        string query = "DELETE FROM BooksTbl WHERE Bid=" + key + ";";
                        using (SqlCommand cmd = new SqlCommand(query, con))
                        {
                            cmd.ExecuteNonQuery();
                        }
                    }

                    MessageBox.Show("book data deleted successfully");
                    populate();
                    Reset();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void editbtn_Click(object sender, EventArgs e)
        {

            if (Btitletb.Text == "" || Bautb.Text == "" || qtytb.Text == "" || bptb.Text == "" || bcatcb.SelectedIndex == -1)
            {
                MessageBox.Show("Missing information");
            }
            else
            {
                try
                {
                    int key = Convert.ToInt32(bookDGV.SelectedRows[0].Cells[0].Value);

                    using (SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=bookshopp;Integrated Security=True"))
                    {
                        con.Open();
                        string query = "UPDATE BooksTbl SET BTitle='" + Btitletb.Text + "', BAuthor='" + Bautb.Text + "', BCatogory='" + bcatcb.SelectedItem.ToString() + "'  , BQantity= " + qtytb.Text + ", BPrice = " + bptb.Text + "   WHERE Bid=" + key;
                        SqlCommand cmd = new SqlCommand(query, con);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("book data updated successfully");
                    }

                    populate();
                    Reset();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void label12_Click(object sender, EventArgs e)
        {
            login obj = new login();
            obj.Show();
            this.Hide();
        }

        private void label11_Click(object sender, EventArgs e)
        {
            user obj = new user();
            obj.Show();
            this.Hide();
        }

        private void label13_Click(object sender, EventArgs e)
        {
            dashboard obj = new dashboard();
            obj.Show();
            this.Hide();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
