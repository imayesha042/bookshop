﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;



namespace bookshop
{
    public partial class billing : Form
    {
        public billing()
        {
            InitializeComponent();
            populate();
        }
        SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=bookshopp;Integrated Security=True");
        private void populate()
        {
            con.Open();
            string query = "SELECT * FROM BooksTbl";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            bookDGV.DataSource = ds.Tables[0];
            con.Close();
        }

        private void updatebook()
        {
            int newqty = stock - Convert.ToInt32(qtytb.Text);
            try
            {
                {
                    key = Convert.ToInt32(bookDGV.SelectedRows[0].Cells[0].Value);
                    using (SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=bookshopp;Integrated Security=True"))
                    {
                        con.Open();
                        string query = "UPDATE BooksTbl SET BQantity=" + newqty + " WHERE Bid=" + key + ";";
                        SqlCommand cmd = new SqlCommand(query, con);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Book updated successfully");
                        con.Close();
                    }

                    populate();
                    // Reset();
                }
            }
            catch (Exception Ex)
            {
                MessageBox.Show(Ex.Message);
            }

        }
        int n = 0, gtotal = 0;

        private void savebtn_Click(object sender, EventArgs e)
        {
                        if (qtytb.Text == "" || Convert.ToInt32(qtytb.Text) > stock)
            {
                MessageBox.Show("Not enough stock.");

            }


            else
            {

                int total = Convert.ToInt32(qtytb.Text) * Convert.ToInt32(bptb.Text);

                DataGridViewRow newrow = new DataGridViewRow();
                newrow.CreateCells(billDGV);
                newrow.Cells[0].Value = (n + 1);
                newrow.Cells[1].Value = Btitletb.Text;
                newrow.Cells[2].Value = qtytb.Text;
                newrow.Cells[3].Value = bptb.Text;
                newrow.Cells[4].Value = total;
                billDGV.Rows.Add(newrow);
                n++;

               updatebook();
               gtotal = gtotal + total;
                   totaltbl.Text = "RS  " + gtotal;
            }
        }
        int key = 0,stock=0;

        private void bookDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
                        Btitletb.Text = bookDGV.SelectedRows[0].Cells[1].Value.ToString();
            //qtytb.Text = bookDGV.SelectedRows[0].Cells[4].Value.ToString();
            bptb.Text = bookDGV.SelectedRows[0].Cells[5].Value.ToString();
            if (Btitletb.Text == "")
            {
                key = 0;
                stock = 0;
            }
            else
            {
                key = Convert.ToInt32(bookDGV.SelectedRows[0].Cells[0].Value.ToString());
                stock = Convert.ToInt32(bookDGV.SelectedRows[0].Cells[4].Value.ToString());
            }
        }
        public void Reset()
        {
            Btitletb.Text = "";
            qtytb.Text = "";
            clienttb.Text = "";
            bptb.Text = "";
        }

        private void resetbtn_Click(object sender, EventArgs e)
        {
        Reset();
        }
        int prodid, prodqty, proprice, tottal, pos = 60;
        string prodname;

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {

            // pos = 60;
            e.Graphics.DrawString("   Book Shop", new Font("Century Gothic", 12, FontStyle.Bold), Brushes.LawnGreen, new Point(80));
            e.Graphics.DrawString("ID  PRODUCT   PRICE    QUANTITY  TOTAL ", new Font("Century Gothic", 10, FontStyle.Bold), Brushes.DeepPink, new Point(26, 40));

            foreach (DataGridViewRow row in billDGV.Rows)
            {

                prodid = Convert.ToInt32(row.Cells["Column1"].Value);
                prodname = "" + (row.Cells["Column2"].Value);
                proprice = Convert.ToInt32(row.Cells["Column3"].Value);
                prodqty = Convert.ToInt32(row.Cells["Column4"].Value);
                tottal = Convert.ToInt32(row.Cells["Column5"].Value);

                e.Graphics.DrawString("" + prodid, new Font("Century Gothic", 8, FontStyle.Bold), Brushes.Blue, new Point(26, pos));
                e.Graphics.DrawString("" + prodname, new Font("Century Gothic", 8, FontStyle.Bold), Brushes.Blue, new Point(45, pos));
                e.Graphics.DrawString("" + proprice, new Font("Century Gothic", 8, FontStyle.Bold), Brushes.Blue, new Point(120, pos));
                e.Graphics.DrawString("" + prodqty, new Font("Century Gothic", 8, FontStyle.Bold), Brushes.Blue, new Point(170, pos));
                e.Graphics.DrawString("" + tottal, new Font("Century Gothic", 8, FontStyle.Bold), Brushes.Blue, new Point(235, pos));

                pos = pos + 20;


            }

            e.Graphics.DrawString("Grand total : RS" + gtotal, new Font("Century Gothic", 12, FontStyle.Bold), Brushes.Crimson, new Point(60, pos + 50));
            e.Graphics.DrawString("**********BookStore********", new Font("Century Gothic", 10, FontStyle.Bold), Brushes.Crimson, new Point(40, pos + 85));

            billDGV.Rows.Clear();
            billDGV.Refresh();
            pos = 100;
            gtotal = 0;

        }

        private void printbtn_Click(object sender, EventArgs e)
        {

            if (clienttb.Text == "" || Btitletb.Text == "")
            {
                MessageBox.Show("select client name");
            }
            else
            {
                try
                {

                    con.Open();
                    string query = "INSERT INTO Bill  VALUES ('" + username.Text + "','" + clienttb.Text + "' , " + gtotal + ")";

                    SqlCommand cmd = new SqlCommand(query, con);



                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Bill save successfully");
                    con.Close();

                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }


                printDocument1.DefaultPageSettings.PaperSize = new System.Drawing.Printing.PaperSize("pprnm", 385, 600);
                if (printPreviewDialog1.ShowDialog() == DialogResult.OK)
                {
                    printDocument1.Print();
                }

            }
        }

        private void billing_Load(object sender, EventArgs e)
        {
            username.Text = login.UserName;
        }

        private void panel5_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {
            login obj = new login();
            obj.Show();
            this.Hide();
        }

        private void label8_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }


        }


        }
    
