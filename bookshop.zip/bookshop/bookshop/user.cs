﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace bookshop
{
    public partial class user : Form
    {
        public user()
        {
            InitializeComponent();
            populate();
        }
        SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=bookshopp;Integrated Security=True");
        private void populate()
        {
            con.Open();
            string query = " select * from  userTbl";
            SqlDataAdapter sda = new SqlDataAdapter(query, con);
            SqlCommandBuilder builder = new SqlCommandBuilder(sda);
            var ds = new DataSet();
            sda.Fill(ds);
            userDGV.DataSource = ds.Tables[0];
            con.Close();
        }
      

        private void savebt_Click(object sender, EventArgs e)
        {
            if (usernameTb.Text == "" || phoneTb.Text == "" || addressTb.Text == "" || passwordTb.Text == "")
            {
                MessageBox.Show("Missing information");
            }
            else
            {
                try
                {
                    con.Open();
                    string query = "insert into  userTbl values ('" + usernameTb.Text + "','" + phoneTb.Text + "','" + addressTb.Text + "','" + passwordTb.Text + "')";
                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("user  data save successfully");
                    con.Close();
                    populate();

                   // Reset();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void label8_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        public void Reset()
        {

            usernameTb.Text = "";
            phoneTb.Text = "";
            addressTb.Text = "";
            passwordTb.Text = "";
        }

        private void resetbt_Click(object sender, EventArgs e)
        {
            Reset();
        }

        private void deletebt_Click(object sender, EventArgs e)
        {
            if (usernameTb.Text == "" || phoneTb.Text == "" || addressTb.Text == "" || passwordTb.Text == "")
            {
                MessageBox.Show("missing information");
            }
            else
            {

                try
                {
                    int key = Convert.ToInt32(userDGV.SelectedRows[0].Cells[0].Value);

                    using (SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=bookshopp;Integrated Security=True"))
                    {
                        con.Open();
                        string query = "DELETE FROM userTbl WHERE uid=" + key + ";";
                        using (SqlCommand cmd = new SqlCommand(query, con))
                        {
                            cmd.ExecuteNonQuery();
                        }
                    }

                    MessageBox.Show("user data deleted successfully");
                    populate();
                    Reset();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }
        int key = 0;
        private void userDGV_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            usernameTb.Text = userDGV.SelectedRows[0].Cells[1].Value.ToString();
            phoneTb.Text = userDGV.SelectedRows[0].Cells[2].Value.ToString();

            addressTb.Text = userDGV.SelectedRows[0].Cells[3].Value.ToString();
            passwordTb.Text = userDGV.SelectedRows[0].Cells[4].Value.ToString();
            if (usernameTb.Text == "")
            {
                key = 0;
            }
            else
            {
                key = Convert.ToInt32(userDGV.SelectedRows[0].Cells[0].Value.ToString());
            }

        }

        private void editbt_Click(object sender, EventArgs e)
        {

            if (usernameTb.Text == "" || phoneTb.Text == "" || addressTb.Text == "" || passwordTb.Text == "")
            {
                MessageBox.Show("Missing information");
            }
            else
            {
                try
                {
                    int key = Convert.ToInt32(userDGV.SelectedRows[0].Cells[0].Value);

                    using (SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=bookshopp;Integrated Security=True"))
                    {
                        con.Open();
                        string query = "UPDATE userTbl SET UName='" + usernameTb.Text + "', UPhone='" + phoneTb.Text + "', UAddress='" + addressTb.Text + "', UPassword= '" + passwordTb.Text + "' WHERE Uid=" + key;
                        SqlCommand cmd = new SqlCommand(query, con);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("user data updated successfully");
                    }

                    populate();
                    Reset();
                }
                catch (Exception Ex)
                {
                    MessageBox.Show(Ex.Message);
                }
            }
        }

        private void label12_Click(object sender, EventArgs e)
        {
            login obj = new login();
            obj.Show();
            this.Hide();
        }

        private void label10_Click(object sender, EventArgs e)
        {
            books obj = new books();
            obj.Show();
            this.Hide();
        }

        private void label13_Click(object sender, EventArgs e)
        {
            dashboard obj = new dashboard();
            obj.Show();
            this.Hide();
        }

    }
}
