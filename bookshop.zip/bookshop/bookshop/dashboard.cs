﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace bookshop
{
    public partial class dashboard : Form
    {
        public dashboard()
        {
            InitializeComponent();
        }

        private void label12_Click(object sender, EventArgs e)
        {
            login obj = new login();
            obj.Show();
            this.Hide();
        }

        private void label10_Click(object sender, EventArgs e)
        {
            books obj = new books();
            obj.Show();
            this.Hide();
        }

        private void label11_Click(object sender, EventArgs e)
        {
           user obj = new user();
            obj.Show();
            this.Hide();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
        SqlConnection con = new SqlConnection(@"Data Source=.;Initial Catalog=bookshopp;Integrated Security=True");

        private void dashboard_Load(object sender, EventArgs e)
        {
            con.Open();

            SqlDataAdapter sda = new SqlDataAdapter("SELECT SUM(CONVERT(INT, BQantity)) FROM BooksTbl", con);
            DataTable dt = new DataTable();
            sda.Fill(dt);
            bookstock.Text = dt.Rows[0][0].ToString();

            SqlDataAdapter sdaa = new SqlDataAdapter("SELECT SUM(CONVERT(INT, Amount)) FROM bill", con);

            DataTable dtt = new DataTable();
            sdaa.Fill(dtt);
            amountstock.Text = dtt.Rows[0][0].ToString();
            Console.WriteLine(dtt.Rows[0][0].ToString());
            SqlDataAdapter sda2 = new SqlDataAdapter("SELECT Count(*) FROM userTbl", con);

            DataTable dtt2 = new DataTable();
            sda2.Fill(dtt2);
            int count = Convert.ToInt32(dtt2.Rows[0][0]);
            userstock.Text = dtt2.Rows[0][0].ToString();
            Console.WriteLine(dtt2.Rows[0][0].ToString());



            con.Close();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
